--Hello CHAMPIONS Tech--
------------------------
Here We've listed the important tips to succesful upload Products(Items) respecting their details.

>To avoid EXCEL-Extension Missmatching due to Ms-Versions, Fill the 'ProductsFormat' that is downloaded as a sample
>Do not indicate LIST-TiTLES like (ItemName,...)
>Respect this Culumn Order:

	>First Column: Item Name
	>Second Column: Category
	>Third Column: Set-Type 
	>Fourth Column: Qnt Available 
	>Firth Column: Box_Pieces
	>Sixth Column: Warehouse





	
   ATTENTION: Fill-in the Excel file with the collect values matching to the one recorded in the system to avoid any mismatching


!!!!!!!!! THANK YOU !!!!!!!!