--Hello CHAMPIONS Tech--
------------------------
Here We've listed the important tips to succesful upload Products(Items) respecting their details.

>To avoid EXCEL-Extension Missmatching due to Ms-Versions, Fill the 'ProductsFormat' that is downloaded as a sample
>Do not indicate LIST-TiTLES like (ItemName,...)
>Respect this Culumn Order:

	>First Column: ItemName
	>Second Column: ItemCategory (Refer to Category Relerationship Below)
	>Third Column: Is Item Box type (set of items) {if YES:put 1, if NOT:put 0} 
	>Fourth Column: Number of Pieces (If The third column is YES, Leave it BLANK if not) 


**CATEGORY RELATIONSHIP
---------------------
	1 : Electronics
	2 : Furnitures
	3 : Others
	4 : IT
	5 : Networking
	6 : Stetioneries
	7 : Hardware
	
   TIP: You can use Excel_Formula to Determine these numbers


!!!!!!!!! THANK YOU !!!!!!!!